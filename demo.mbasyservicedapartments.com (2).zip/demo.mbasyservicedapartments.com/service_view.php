<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700&display=swap" rel="stylesheet">
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>mbasyservicedapartments | Search our stunning collection of Birmingham homes</title>
</head>
<body>
    <!--header-->
    <?php require 'partials/_header.php' ?>
    <!-- slider + Booking filteration -->
    <div class="listing_view_hero_content d-flex flex-column flex-lg-row">
        <!-- slider -->
        <div class="perfect-stay-left-section">
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/slider-1.jpg">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider-2.jpg">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider-3.jpg">
                    </div>
                    <div class="carousel-item">
                        <img src="img/slider-4.jpg">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                    <div class="navigation-btn">
                        <i class="fa-solid fa-chevron-left"></i>
                    </div>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                    <div class="navigation-btn">
                        <i class="fa-solid fa-chevron-right"></i>
                    </div>
                </button>
            </div>
        </div>
        <!-- booking search -->
        <div class="perfect-stay-right-section">
            <div class="container p-2 py-4 py-lg-2">
                <div class="row g-0 pb-4 align-items-center justify-content-center border-bottom separator-black">
                    <div class="col ms-3">
                        <h3 class="mb-0 fw-light">2BR Downtown | Burj Khalifa view | Pool |Fast WIFI</h3>
                    </div>
                    <div class="col-auto text-center ms-2 fw-light">
                        <h3 class="mb-3 fw-light">د.إ700</h3>
                        <div>Avg. per night</div>
                    </div>
                </div>
                <div class="row g-0">
                    <div id="booknowsearchForm1">
                        <div class="container p-2">
                            <div class="hero-search-form justify-content-center row g-0">
                                <div class="col-md-5 me-auto">
                                    <div class="search-item-2 d-flex align-items-center">
                                        <span>Check in</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="search-item-2 my-2 my-md-0 d-flex align-items-center">
                                        <span>Check out</span>
                                    </div>
                                </div>
                                <div class="col-md-12 my-2">
                                    <div class="search-item-2 d-flex align-items-center">
                                        <span>Guests</span> <i class="fa-solid ms-auto fa-chevron-down"></i>
                                    </div>
                                </div>
                                <a href="book_now.php" class="text-decoration-none d-block w-100"><button type="submit" class="w-100 my-btn">Book</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- other content + facilities -->
    <div class="container">
        <div class="row g-0">
            <div class="col-lg-10 offset-lg-1">
                <div class="mt-sm-5 bg-faded-2 listing-general-info">
                    <div class="row g-0 separator">
                        <div class="col-xl p-sm-5 pt-5 px-2 listing-general-info-row separator">
                            <div class="d-flex justify-content-between">
                                <div class="listing-general-info-item me-0 me-md-4 mb-4 mb-md-0">
                                    <div class="icon-label d-flex align-items-center flex-column contained">
                                        <div style="width:40px;height:40px;" class="icon-wrap mb-2"><img class="w-100 h-100" src="https://pmwebsite-a8eae.firebaseapp.com/static/media/listing_guests.b6f69025.svg" alt="listing_guests"></div>
                                        <div class="wide">
                                            <div class="line-height-12"><small class="d-block d-sm-inline text-center">4</small> <small>guests</small></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="listing-general-info-item me-0 me-md-4 mb-4 mb-md-0">
                                    <div class="icon-label d-flex align-items-center flex-column contained">
                                        <div style="width:40px;height:40px;" class="icon-wrap mb-2"><img class="w-100 h-100" src="https://pmwebsite-a8eae.firebaseapp.com/static/media/listing_bedrooms.7ddd6a2a.svg" alt="listing_bedrooms"></div>
                                        <div class="wide">
                                            <div class="line-height-12"><small class="d-block d-sm-inline text-center">2</small> <small>bedrooms</small></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="listing-general-info-item me-0 me-md-4 mb-4 mb-md-0">
                                    <div class="icon-label d-flex align-items-center flex-column contained">
                                        <div style="width:40px;height:40px;" class="icon-wrap mb-2"><img class="w-100 h-100" src="https://pmwebsite-a8eae.firebaseapp.com/static/media/listing_beds.7143f54e.svg" alt="listing_beds"></div>
                                        <div class="wide">
                                            <div class="line-height-12"><small class="d-block d-sm-inline text-center">2</small> <small>beds</small></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="listing-general-info-item">
                                    <div class="icon-label d-flex align-items-center flex-column contained">
                                        <div style="width:40px;height:40px;" class="icon-wrap mb-2"><img class="w-100 h-100" src="https://pmwebsite-a8eae.firebaseapp.com/static/media/listing_bathroom.31f189cc.svg" alt="listing_bathroom"></div>
                                        <div class="wide">
                                            <div class="line-height-12"><small class="d-block d-sm-inline text-center">2</small> <small>bathrooms</small></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl py-5 text-center listing-address">
                            <div class="icon-label d-flex align-items-center flex-column contained">
                                <div class="icon-wrap mb-2"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/listing_location.75e1758b.svg" alt="listing_location"></div>
                                <small class="fw-light">Dubai, United Arab Emirates</small>
                            </div>
                        </div>
                    </div>
                    <div class="row g-0">
                        <div class="col-xl-6 py-5 px-4">
                            <div class="wide">
                                <section style="padding: 0px;">We are proud to present this newly furnished beautiful two bedroom apartment in Dubai Downtown with signature Burj Views .<br><br>Designed beautifully to compliment the Dubai vibe with a modern sleek feel of Dubai to suit our guests. Our premium furnishings are luxurious and comfortable. Our fresh and unique art pieces reflect our refreshing mid-century modern design. Its one of a kind! <br><br>The whole group will enjoy easy access to everything from this centrally located place.</section>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <iframe class="mx-auto mx-xl-0 d-block w-100 mb-2" src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d190394.60051178196!2d-101.44017845448415!3d39.872282519670755!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1656227676235!5m2!1sen!2s" width="500" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="separator pt-5">
            <div class="listing-page-section px-5" style="max-height: none;">
                <div class="row no-gutters pb-5">
                    <div class="col-sm listing-page-section-inner" style="padding-left: 8rem;">
                        <h5>Check in and out</h5>
                        <p class="wide">Check in: 15:00<br>Check out: 11:00</p>
                    </div>
                    <div class="col-sm listing-page-section-inner">
                        <h5>Prices</h5>
                        <div class="wide">
                            <div>Weekly discount:&nbsp;5%</div>
                            <div>Monthly discount:&nbsp;25%</div>
                            <div>Extra people:د.إ100 per night</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="separator pt-5 amenities-content" style="padding: 0 10rem;">
            <div class="pt-3 p-lg-0" style="padding-left: 2rem;">
                <h5 class="mb-3">Amenities</h5>
                <div class="row no-gutters">
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/elevator.680de118.svg" alt="elevator"></div>
                            <div class="ms-1">Elevator</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/parking.eae9a7e7.svg" alt="parking"></div>
                            <div class="ms-1">Free Parking on Premises</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/pool.b6e54cba.svg" alt="pool"></div>
                            <div class="ms-1">Swimming Pool</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/air_condition.a63d4b3d.svg" alt="air_condition"></div>
                            <div class="ms-1">Air Conditioning</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/wifi.6a27ccc4.svg" alt="wifi"></div>
                            <div class="ms-1">Wireless Internet</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/internet.be6ae7b8.svg" alt="internet"></div>
                            <div class="ms-1">Internet</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/kitchen.ee445ea9.svg" alt="kitchen"></div>
                            <div class="ms-1">Kitchen</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/washer.0d8a62c5.svg" alt="washer"></div>
                            <div class="ms-1">Washer</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/iron.293f24f8.svg" alt="iron"></div>
                            <div class="ms-1">Iron</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/tv.d72f40a6.svg" alt="tv"></div>
                            <div class="ms-1">Cable TV</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/tv.d72f40a6.svg" alt="tv"></div>
                            <div class="ms-1">TV</div>
                        </div>
                    </div>
                    <div class="amenity col-md-4 col-sm-6 mb-3">
                        <div class="icon-label d-flex align-items-center flex-row">
                            <div class="icon-wrap"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/first_aid.5e6cb976.svg" alt="first_aid"></div>
                            <div class="ms-1">First Aid Kit</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="separator pt-5 description-content" style="padding: 0 10rem;">
            <div class="listing-page-section px-4 px-lg-0">
                <div class="row">
                    <div class="col-sm">
                        <h5 class="mb-5">Description</h5>
                        <div>
                            <h6 class="mb-0 h6-text">The Space</h6>
                            <p class="white-space-pre-wrap my-3">The living room will certainly help you to relax with its large and comfy couch, cable TV and Free Netflix. Everything about the apartment is relaxing. It won't even let you miss anything with its fast WiFi.</p>
                            <p>
                                The apartment boasts two balconies to enjoy the stunning view of the Burj Khalifa and Downtown Dubai, from sunrise to sunset. It's definitely an astonishing space for leisure.
                            </p>
                            <p>
                                Dine with takeouts or home-cooked meals with your companions. The fully-equipped kitchen got you covered with all appliances (stove, oven, cookware) for cooking and making coffee.

                            </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- suggested services -->
    <div class="container-fluid">
        <div class="suggested-service mb-5">
            <h2 class="fw-light text-center my-5">Suggested listing</h2>
            <div class="my-container">
                <div class="owl-carousel owl-theme">
                    <div class="item">
                        <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-1.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Opulent Suite- City Centre -  Fast Wifi - Netflix">
                                        <p class="text-overflow-hidden">Opulent Suite- City Centre - Fast Wifi - Netflix</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">6 guests | 2 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£70</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-2.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Address Beach Resort - 1BDR Amazing Marina Views">
                                        <p class="text-overflow-hidden">Address Beach Resort - 1BDR Amazing Marina Views</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">2 guests | 1 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£70</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-3.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Address Beach Resort JBR 1BDR Private Beach| Balcony">
                                        <p class="text-overflow-hidden">Address Beach Resort JBR 1BDR Private Beach| Balcony</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">3 guests | 1 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">د.د.إ1,400</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-4.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Angelic | Spacious 1 BDR Apartment | Large Terrace">
                                        <p class="text-overflow-hidden"> Angelic | Spacious 1 BDR Apartment | Large Terrace</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">2 guests | 1 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£70</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-4.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Apollo Luxury - Netflix - Fast WIFI">
                                        <p class="text-overflow-hidden">Apollo Luxury - Netflix - Fast WIFI</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">4 guests | 2 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£110</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-5.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Aviator Luxury Apartment with Free Parking - City Centre Birmingham">
                                        <p class="text-overflow-hidden">Aviator Luxury Apartment with Free Parking - City Centre Birmingham"</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">6 guests | 2 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£100</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column me-0 text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-5.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Aviator Luxury Apartment with Free Parking - City Centre Birmingham">
                                        <p class="text-overflow-hidden">Aviator Luxury Apartment with Free Parking - City Centre Birmingham"</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">6 guests | 2 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£100</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column me-0 text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-5.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Aviator Luxury Apartment with Free Parking - City Centre Birmingham">
                                        <p class="text-overflow-hidden">Aviator Luxury Apartment with Free Parking - City Centre Birmingham"</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">6 guests | 2 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£100</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="item">
                        <a href="" class="services flex-column me-0 text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                            <div class="suggested-item mb-3" style="background-image: url(img/listing-5.jpg);"></div>
                            <div class="details d-flex justify-content-between">
                                <div class="services-info flex-column me-2 d-flex">
                                    <div class="font-weight-bold listing-title title text-start" title="Aviator Luxury Apartment with Free Parking - City Centre Birmingham">
                                        <p class="text-overflow-hidden">Aviator Luxury Apartment with Free Parking - City Centre Birmingham"</p>
                                    </div>
                                    <div class="font-weight-light title-2 text-start">6 guests | 2 bedrooms</div>
                                </div>
                                <div class="price d-flex align-items-end">       
                                    <div style="font-size: 14px; font-weight:300;">From</div>
                                    <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£100</div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--footer-->
    <?php require 'partials/_footer.php' ?>
    <!--javascripts + owl carousels-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/owl.navigation.js"></script>
    <script src="js/index.js"></script>
</body>
</html>