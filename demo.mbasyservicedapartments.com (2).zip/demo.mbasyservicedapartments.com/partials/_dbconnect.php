<?php
    // Connecting to a DB...
    $servername = "demo.mbasyservicedapartments.com";
    $username = "book_your_room_user";
    $password = "MadriD23!";
    $database = "book_your_room_db";
    $conn = mysqli_connect($servername, $username, $password, $database);
    // Connection checking...
    if(!$conn){
        die("Failed to connect the DB");
    }
?>