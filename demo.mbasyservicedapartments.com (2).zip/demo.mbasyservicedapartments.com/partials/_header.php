<?php
    echo '<nav class="navbar py-0 sticky-top perfect-bg-dark navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand ms-0 ms-lg-4" href="http://demo.mbasyservicedapartments.com/"><img src="img/logo.png" width="90px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <i style="color: #303030;" class="fa-solid fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse ms-3" id="navbarNav">
        <ul class="navbar-nav align-items-start align-items-lg-center ms-auto me-4" style="margin:1rem;">
          <li class="nav-item">
            <a class="nav-link text-uppercase ms-1 fs-7 ms-lg-0" href="http://demo.mbasyservicedapartments.com/#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-uppercase mx-lg-3 mx-0 my-2 fs-7 my-lg-0 ms-1 ms-lg-0" href="http://demo.mbasyservicedapartments.com/#contact">contact</a>
          </li>
          <li class="nav-item">
            <a class="my-btn-outline text-uppercase ms-1 fs-7 ms-lg-0 mb-4 mb-lg-0" href="services.php">book now</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>';
?>