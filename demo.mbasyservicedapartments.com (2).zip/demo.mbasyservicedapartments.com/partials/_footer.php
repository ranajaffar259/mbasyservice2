<?php
echo ' <div class="footer">
<div class="px-3 py-5 footer-wrapper">
    <footer class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1 d-flex align-items-md-center align-items-start flex-column flex-md-row justify-content-between">
                <div class="footer-info">
                    <p class="wide font-weight-normal mb-0">
                        <span>mbasyservicedapartments<br></span>
                        <span class="d-flex flex-column flex-md-row my-1">
                            <a href="mailto:admin@mbasyservicedapartments">
                                <span class="me-md-3 text-decoration-none">admin@mbasyservicedapartments</span>
                            </a>
                            <a href="Tel:+92 308 0049736"><span class="me-md-3">Tel: +92 308 0049736</span></a></span><span class="d-flex flex-column flex-md-row">
                            <a target="_blank" class="me-3 p-0" href="../privacy.php">Privacy Policy</a></span>
                    </p>
                </div>
                <div class="footer-social text-end d-flex justify-content-end mt-md-0 mt-4">
                    <a href="#" class="me-2">
                        <button class="btn btn-info btn-link btn-shape-circle" type="submit">
                            <img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/social_facebook.e9a50a0d.svg" alt="facebook">
                        </button>
                    </a>
                    <a href="#"><button class="btn btn-info btn-link btn-shape-circle" type="submit"><img src="https://pmwebsite-a8eae.firebaseapp.com/static/media/social_instush.31cd89b1.svg" alt="instagram"></button></a>
                </div>
            </div>
        </div>
    </footer>
</div>
</div>';
