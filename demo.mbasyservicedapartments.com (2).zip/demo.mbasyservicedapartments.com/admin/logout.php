<?php
    session_start();
    echo "<p>Logging out Please wait...</p>";
    session_destroy();
    header("Location: https://demo.mbasyservicedapartments.com/admin/login.php");
?>