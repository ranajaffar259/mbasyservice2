<?php
$showAlert = false;
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  include '../partials/_dbconnect.php';
  $roomtitle = $_POST['roomtitle'];
  $roomaddress = $_POST['roomaddress'];
  $roompricepernight = $_POST['roompricepernight'];
  $roomdescription = $_POST['roomdescription'];
  $roomabout = $_POST['roomabout'];
  $roomsliderimage = $_POST['roomsliderimage'];
  $roomdefaultimage = $_POST['roomdefaultimage'];
  $chooseguests = $_POST['chooseguests'];
  $choosebeds = $_POST['choosebeds'];
  $choosebedrooms = $_POST['choosebedrooms'];
  $choosebathrooms = $_POST['choosebathrooms'];
  

  $sql = "INSERT INTO `room_upload` (`title`, `address`, `room_price_per_night`, `description`, `about`, `slider_image`, `default_image`, `guests`, `beds`, `bedrooms`, `bathrooms`) VALUES ('$roomtitle','$roomaddress','$roompricepernight','$roomdescription','$roomabout','$roomsliderimage','$roomdefaultimage','$chooseguests','$choosebeds','$choosebedrooms','$choosebathrooms')";

  $result = mysqli_query($conn, $sql) or die("result failed");

  if ($result == true) {
    $showAlert = true;
  }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - mbasyservicedapartments</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <?php
        session_start();
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
            
        }  
        else {
            header("Location: https://demo.mbasyservicedapartments.com/admin/login.php");
        }
        
    ?>
    <!--navbar-->
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3 text-white fs-6" href="https://demo.mbasyservicedapartments.com/admin">mbasyservicedapartments</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        <ul class="navbar-nav ms-auto me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li class="mx-3">' . $_SESSION['username'] . '</li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <a class="nav-link" href="https://demo.mbasyservicedapartments.com/admin">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                        </div>
                        <div class="nav">
                            <a class="nav-link" href="upload.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-upload"></i></div>
                                Upload Room
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer bg-dark">
                        <div class="small text-white">Logged in as: ' . $_SESSION['username'] . '</div>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <?php
                 if ($showAlert) {
                    echo '<div class="alert-room-uploaded alert px-3 shadow-sm border-bottom rounded-0 text-dark alert-dismissible fade show border-radius-none" role="alert">
                          Your room has successfully uploaded
                          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';
                 }
                ?>
                <main class="container-lg h-100">
                    <form class="mx-auto p-2" action=" <?php $_SERVER["PHP_SELF"]; ?>" method="POST">
                        <h2 class="text-center my-3" style="font-family: sans-serif;text-transform: uppercase;font-weight: 600;">Upload Room</h2>
                        <div class="row mb-3">
                            <div class="col-md-4 mb-md-0 mb-3">
                              <label for="title1" class="form-label" onselectstart="return false"><small>Room Title</small></label>
                              <input class="form-control" name="roomtitle" type="text" id="title1" required>
                            </div>
                        
                            <div class="col-md-4 mb-md-0 mb-3">
                              <label for="address1" class="form-label" onselectstart="return false"><small>Room Address / Location</small></label>
                              <input class="form-control" name="roomaddress" type="text" id="address1" required>
                            </div>
                              
                            <div class="col-md-4 mb-md-0 mb-3">
                              <label for="price1" class="form-label" onselectstart="return false"><small>Room Price / Per Night</small></label>
                              <input class="form-control" name="roompricepernight" type="text" id="price1" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 mb-md-0 mb-3">
                              <label for="Textarea1" class="form-label" onselectstart="return false"><small>Room Description</small></label>
                              <textarea class="form-control" name="roomdescription" id="Textarea1" rows="4" required></textarea>
                            </div>           
                            <div class="col-md-4 mb-md-0 mb-3">
                              <label for="Textarea2" class="form-label" onselectstart="return false"><small>Tell Something About Room</small></label>
                              <textarea class="form-control" id="Textarea2" name="roomabout" rows="4" required></textarea>
                            </div>                
                            <div class="col-md-4 mb-md-0 mb-3 d-flex justify-content-center flex-column">
                              <label for="" class="form-label"><small>Room Slider Images</small></label>
                              <input class="form-control form-control-sm" name="roomsliderimage" type="file" id="" multiple required>
                              <label for="" class="form-label mt-2"><small>Default Room Image</small></label>
                              <input class="form-control form-control-sm" name="roomdefaultimage" type="file" id="" multiple required>
                            </div>
                        </div>           
                        <div class="row mb-3">    
                            <div class="col-md-3 mb-md-0 mb-3">
                              <label for="validationTooltip04" class="form-label" onselectstart="return false"><small>Total Guests Capacity</small></label>
                              <select class="form-select" id="validationTooltip04" required name="chooseguests">
                                <option selected disabled value="">Choose...</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                              </select>
                            </div>
                            
                            <div class="col-md-3 mb-md-0 mb-3">
                              <label for="validationTooltip05" class="form-label" onselectstart="return false"><small>Total Beds</small></label>
                              <select class="form-select" id="validationTooltip05" required name="choosebeds">
                                <option selected disabled value="">Choose...</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                              </select>
                            </div>
                                
                           <div class="col-md-3 mb-md-0 mb-3">
                              <label for="validationTooltip06" class="form-label" onselectstart="return false"><small>Total Bedrooms</small></label>
                              <select class="form-select" id="validationTooltip06" required name="choosebedrooms">
                                <option selected disabled value="">Choose...</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                              </select>
                            </div>
                        
                            <div class="col-md-3 mb-md-0 mb-3">
                              <label for="validationTooltip07" class="form-label" onselectstart="return false"><small>Total Bathrooms</small></label>
                              <select class="form-select" id="validationTooltip07" required name="choosebathrooms">
                                <option selected disabled value="">Choose...</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                              </select>
                            </div>
                            
                    </div>
                        <div class="row mb-3">    
                           <h6 class="fs-5 my-3">Facilities</h6>
                           <div class="col-md-4 mb-md-0 mb-3">
                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" id="defaultCheck1" name="">
                                  <label class="form-check-label" for="defaultCheck1">
                                    <small>name</small>
                                  </label>
                                </div>
                            </div>
                        </div>
                        <div class="my-3">
                          <button class="btn btn-outline-secondary" type="submit">Publish Room</button>
                        </div>
                    </form>
                    <?php
                        $faciadd = false;
                        if($_SERVER['REQUEST_METHOD'] == "POST"){
                         include '../partials/_dbconnect.php';
                         $facilities_name = $_POST['facilities_name'];
                         $facilities_image = $_POST['facilities_image'];
                         
                         $facilitiesSQL = "INSERT INTO `add_facilities` (`facilities_name`,`facilities_image`) VALUES ('$facilities_name','$facilities_image')";
                         $facilitiesRESULT = mysqli_query($conn, $facilitiesSQL);
                       
                         if($facilitiesRESULT){
                            $faciadd = true;
                         }
                        }
                    ?>
                    <form class="p-2" action=" <?php $_SERVER['PHP_SELF']; ?>" method="POST">
                        <div class="row mb-3 justify-content-end">
                            <div class="col-md-3 mb-md-0 mb-3">
                                <?php
                                    if($faciadd){
                                        echo '<div class="p-2 my-2 rounded alert-room-uploaded">Facilities Added</div>';
                                    }
                                ?>
                                <label for="addf" class="form-label" onselectstart="return false"><small>Add Facilities</small></label>
                                <input class="form-control mb-2" name="facilities_name" type="text" id="addf" required>
                                <label for="addf" class="form-label" onselectstart="return false"><small>Add Facilities Image</small></label>
                                <input class="form-control mb-2 form-control-sm" name="facilities_image" type="file" multiple required>
                                <button type="submit" class="btn btn-sm btn-outline-secondary my-2">Add</button>
                            </div>
                        </div>
                    </form>
                </main>
                <!--footer-->
                <footer class="py-3 bg-dark mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-end small">
                            <div class="text-white">Copyright &copy; Mbasy Serviced Apartments <?php echo date("Y"); ?> | All Right Reserved</div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
    <script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    </script>
</body>

</html>