<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700&display=swap" rel="stylesheet">
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>mbasyservicedapartments | Search our stunning collection of Birmingham homes</title>
</head>
<body>
    <!--header + nav-->
    <nav class="navbar py-0 fixed-top perfect-bg-dark navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand ms-0 ms-lg-4" href="http://demo.mbasyservicedapartments.com/"><img src="img/logo.png" width="90px"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i style="color: #303030;" class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse ms-4" id="navbarNav">
                <ul class="navbar-nav align-items-start align-items-lg-center ms-auto me-4" style="margin:1rem;">
                    <li class="nav-item">
                        <a class="nav-link text-uppercase ms-1 fs-7 ms-lg-0" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-uppercase mx-lg-3 mx-0 my-2 fs-7 my-lg-0 ms-1 ms-lg-0" href="#contact">contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="my-btn-outline text-uppercase ms-1 fs-7 ms-lg-0 mb-4 mb-lg-0" href="services.php">book now</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Main content -->
    <div class="content">
        <!-- Banner -->
        <div class="hero-section text-white d-flex justify-content-center align-items-center flex-colum">
            <div class="container" style="z-index:1;">
                <div class="hero-info">
                    <h1 class="text-center">STAY PERFECT</h1>
                    <p class="text-center">Search our stunning collection of Birmingham homes</p>
                </div>
                <div class="hero-search-form justify-content-center row g-0">
                    <div class="col-md-3">
                        <div class="search-item-1 d-flex align-items-center">
                            <span>City</span> <i class="fa-solid ms-auto fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="col-md-4 ms-0 ms-md-2 my-3 my-md-0">
                        <div class="search-item-1 d-flex align-items-center">
                            <span>Check in</span><i class="mx-auto fa-solid fa-arrow-right"></i><span>Check out</span>
                        </div>
                    </div>
                    <div class="col-md-2 ms-0 ms-md-2 mb-2 mb-md-0">
                        <div class="search-item-1 d-flex align-items-center">
                            <span>Guests</span> <i class="fa-solid ms-auto fa-chevron-down"></i>
                        </div>
                    </div>
                    <div class="col-md-1 ms-0 ms-md-2">
                        <button type="submit" class="my-btn">Submit</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- About us -->
        <div class="about" id="about">
            <div class="container">
                <h2 class="mb-4">Our Vision</h2>
                <div class="row justify-content-center g-0">
                    <div class="col-md-7">
                        <p class="wide mx-auto text-center">We at MBASY flourish on understanding the importance of delivering the highest quality of hospitality to our guests. We deliver sort after properties available in prime locations finished to the highest standards in order to fulfill the requirements of our guests.Our properties are catered for all your needs whether you are looking for a romantic getaway, business trip, or well-deserved time alone, we at MBASY will provide you accommodation to ensure your stay is an unforgettable one.AT MBASY our team is highly experienced and professional, in order to provide our guests with exceptional service who are able to help you 24/7.MBASY is the perfect choice for your stay.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Services -->
        <div class="text-center px-4 px-sm-3">
            <div class="service-info row">
                <h3>Handpicked homes to inspire your next trip</h3>
                <h4>With our breath taking city apartments, you are sure to find your perfect stay in Birmingham</h4>
            </div>
            <!-- suggested services -->
            <div class="container-fluid">
                <div class="suggested-service mb-5">
                    <div class="my-container">
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                                    <div class="suggested-item mb-3" style="background-image: url(img/listing-4.jpg);"></div>
                                    <div class="details d-flex justify-content-between">
                                        <div class="services-info flex-column me-2 d-flex">
                                            <div class="font-weight-bold listing-title title text-start" title="Angelic | Spacious 1 BDR Apartment | Large Terrace">
                                                <p class="text-overflow-hidden"> Angelic | Spacious 1 BDR Apartment | Large Terrace</p>
                                            </div>
                                            <div class="font-weight-light title-2 text-start">2 guests | 1 bedrooms</div>
                                        </div>
                                        <div class="price d-flex align-items-end">
                                            <div style="font-size: 14px; font-weight:300;">From</div>
                                            <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£70</div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item">
                                <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                                    <div class="suggested-item mb-3" style="background-image: url(img/listing-4.jpg);"></div>
                                    <div class="details d-flex justify-content-between">
                                        <div class="services-info flex-column me-2 d-flex">
                                            <div class="font-weight-bold listing-title title text-start" title="Angelic | Spacious 1 BDR Apartment | Large Terrace">
                                                <p class="text-overflow-hidden"> Angelic | Spacious 1 BDR Apartment | Large Terrace</p>
                                            </div>
                                            <div class="font-weight-light title-2 text-start">2 guests | 1 bedrooms</div>
                                        </div>
                                        <div class="price d-flex align-items-end">
                                            <div style="font-size: 14px; font-weight:300;">From</div>
                                            <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£70</div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="item">
                                <a href="" class="services flex-column text-decoration-none d-flex justify-content-center col-sm-4 text-dark" tabindex="0">
                                    <div class="suggested-item mb-3" style="background-image: url(img/listing-4.jpg);"></div>
                                    <div class="details d-flex justify-content-between">
                                        <div class="services-info flex-column me-2 d-flex">
                                            <div class="font-weight-bold listing-title title text-start" title="Angelic | Spacious 1 BDR Apartment | Large Terrace">
                                                <p class="text-overflow-hidden"> Angelic | Spacious 1 BDR Apartment | Large Terrace</p>
                                            </div>
                                            <div class="font-weight-light title-2 text-start">2 guests | 1 bedrooms</div>
                                        </div>
                                        <div class="price d-flex align-items-end">
                                            <div style="font-size: 14px; font-weight:300;">From</div>
                                            <div class="text-right col-auto text-tall fs-5 ms-2 title-2" style="font-weight: 300;">£70</div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         <!--Map-->
        <div class="container">
            <div class="row g-0 mb-4">
            <div class="col-sm-12">
                <iframe class="mt-5 home-map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d77762.85290000484!2d-1.9336708544705792!3d52.47752147716896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4870942d1b417173%3A0xca81fef0aeee7998!2sBirmingham%2C%20UK!5e0!3m2!1sen!2s!4v1656096527510!5m2!1sen!2s" allowfullscreen="" loading="fast" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
        </div>
        <!-- Contact us -->
        <div class="contact" id="contact">
            <h2 class="mb-3 mb-md-4 text-center">Contact us</h2>
            <div class="contact-section">
                <?php
                // By default values
                $insert = false;
    
                if($_SERVER['REQUEST_METHOD'] == 'POST'){

                    $name =  $_POST["name"];
                    $email = $_POST["email"];
                    $subject = $_POST["subject"];
                    $description = $_POST["description"];
                        
                $sql = "INSERT INTO `contact_form` (`name`, `email`, `subject`, `description`, `date_time`) VALUES ('$name', '$email', '$subject', '$description', current_timestamp())";
            
                $result = mysqli_query($conn, $sql);
                    if($result){
                        $insert = true;
                    }
                }
                
                if (!$insert == false) {
                    echo '<div class="thanks my-5 d-flex justify-content-center align-items-center flex-column">
                    <img src="img/form_sent_success.svg" alt="">
                    <h2>Thanks</h2>
                    <p>Your request has been successfully sent.</p>
                    </div>';
                } 
                else {
                    echo '
                    <form action="index.php#contact" method="post" class="container px-4 contact-form">
                    <p class="text-center" style="font-size: 14px ; font-weight: 300; margin-bottom: 2rem;">Feel free to contact us and we will get back to you shortly</p>
                    <div class="row g-0">
                    <div class="form-group mb-3 col-sm-5" style="margin-right: 10px;">
                    <input class="form-control form-control-lg" name="name" placeholder="Name" required>
                    </div>
                    <div class="form-group mb-3 col">
                    <input class="form-control form-control-lg" name="email" placeholder="Email" required>
                    </div>
                    </div>
                    <div class="row g-0">
                    <div class="form-group mb-3 col">
                            <input class="form-control form-control-lg" name="subject" placeholder="Subject" required>
                        </div>
                    </div>
                    <div class="row g-0">
                        <div class="form-group mb-3 col">
                            <textarea placeholder="Message" class="form-control form-control-lg" name="description" rows="10" required></textarea>
                        </div>
                    </div>
                    <div class="row g-0" style="height: 40px;">
                        <button class="submit-btn ms-sm-auto" type="submit" style="background: rgb(203, 177, 149);">Send</button>
                    </div>
                    </form>';
                }

                ?>
            </div>
        </div>
    </div>
    <!--Footer-->
    <?php require 'partials/_footer.php' ?>
    <!--javascripts + owl carousels-->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/owl.navigation.js"></script>
    <script src="js/index.js"></script>
    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>