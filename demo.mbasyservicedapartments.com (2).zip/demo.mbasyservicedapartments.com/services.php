<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700&display=swap" rel="stylesheet">
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>mbasyservicedapartments | Search our stunning collection of Birmingham homes</title>
</head>
<body>
    <!--header-->
    <?php require 'partials/_header.php' ?>
    <!--booking filteration-->
    <div id="booknowsearchForm">
        <div class="container">
            <div class="hero-search-form justify-content-center row g-0">
                <div class="col-md-3">
                    <div style="background-color: #fff;" class="search-item-2 d-flex align-items-center">
                        <span>City</span> <i class="fa-solid ms-auto fa-chevron-down"></i>
                    </div>
                </div>
                <div class="col-md-4 ms-0 ms-md-2 my-3 my-md-0">
                    <div style="background-color: #fff;" class="search-item-2 d-flex align-items-center">
                        <span>Check in</span><i class="mx-auto fa-solid fa-arrow-right"></i><span>Check out</span>
                    </div>
                </div>
                <div class="col-md-2 ms-0 ms-md-2 mb-2 mb-md-0">
                    <div style="background-color: #fff;" class="search-item-2 d-flex align-items-center">
                        <span>Guests</span> <i class="fa-solid ms-auto fa-chevron-down"></i>
                    </div>
                </div>
                <div class="col-md-1 ms-0 ms-md-2">
                    <button type="submit" class="my-btn">Submit</button>
                </div>
            </div>
        </div>
    </div>
    <!--main content-->
    <div class="all-content">
        <!-- services + map -->
        <div class="row g-0">
            <!-- services -->
            <div class="col-md-7 g-0 d-flex flex-column">
                <div class="d-flex flex-wrap pt-3 px-3 listings-list justify-content-center justify-content-md-start">
                    <a href="service_view.php" class="services px-sm-3 text-decoration-none d-flex col-lg-6 text-dark" tabindex="0">
                        <div class="img-service" style="background-image: url(img/listing-1.jpg);"></div>
                        <div class="details align-items-center mt-3 d-flex justify-content-between">
                            <div class="services-info me-2 d-flex">
                                <div class="font-weight-bold listing-title title text-start" title="2BR Downtown | Burj Khalifa view | Pool |Fast WIFI">2BR Downtown | Burj Khalifa view | Pool | Fast WIFI</div>
                                <div class="font-weight-light title-2 text-start">4 guests | 2 bedrooms</div>
                            </div>
                            <div class="price d-flex align-items-end flex-column">
                                <div style="font-size: 14px; font-weight:300;">From</div>
                                <div class="text-right col-auto text-tall fs-3 ms-2 title-2 my-1" style="font-weight: 300;">د.إ700</div>
                                <div style="font-size: 14px; font-weight:300;">Per night</div>
                            </div>
                        </div>
                    </a>
                </div>
                <nav class="pt-3 border-top">
                  <ul class="pagination justify-content-center">
                    <li class="page-item">
                      <a class="page-link" href="#" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                      </a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item">
                      <a class="page-link" href="#" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                      </a>
                    </li>
                  </ul>
                </nav>
            </div>
            <!-- map -->
            <div class="col-md-5 py-2 py-md-0 d-none d-md-block">
                <iframe class="px-3 px-md-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d77762.85290000484!2d-1.9336708544705792!3d52.   47752147716896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4870942d1b417173%3A0xca81fef0aeee7998!2sBirmingham%2C%20UK!5e0!3m2!1sen!2s!4v1656096527510!5m2!1sen!2s" height="400" style="border:0;width: 100%;height:100%;" allowfullscreen="" loading="fast" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
        <!-- empty div for spacing -->
        <div class="row g-0">
            <div class="py-2 border-top"></div>
        </div>
    </div>
    <!--footer-->
    <?php require 'partials/_footer.php' ?>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>